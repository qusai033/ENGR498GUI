from flask import Flask, jsonify, render_template, request, abort
import pandas as pd
import numpy as np
from scipy.interpolate import interp1d
import os
from io import StringIO
import matplotlib.pyplot as plt
from scipy.signal import find_peaks
import subprocess
import shutil

app = Flask(__name__)

# Global flag to track script execution
script_run_flag = False

DATA_FILE = '/home/tuser/Desktop/ENGR498/ARULE4Python/ARULE/DATA/DOUT/ND_1_DW_Team24502_SP4000_1_OUT.csv'
# Path to the directory containing device folders
DATA_DIRECTORY = '../data'  # Relative path to the data folder
# Upload file route
# Path to the directory containing device folders
# Path to the directory containing device folders
UPLOAD_DATA_DIRECTORY = './data/uploads/voltage_log'  # Update to match your directory structure
COUNTER_FILE_DIRECTORY = './data/uploads'  # File to store the counter

COUNTER_FILE = os.path.join(COUNTER_FILE_DIRECTORY, 'file_voltage_counter.txt')
healthy_file_path = "/home/tuser/Desktop/ENGR498/ENGR498GUI/data/uploads/healthy_voltageDecay.csv"


DELTA_T_DIRECTORY = "/home/tuser/Desktop/ENGR498/ARULE4Python/ARULE/DATA/DINP/"
DELTA_T_FILE = os.path.join(DELTA_T_DIRECTORY, "SP4000_1.csv")

BASE_DIRECTORY = "./data/uploads"
UPLOAD_DIRECTORY = os.path.join(BASE_DIRECTORY, "voltage_log")
RINGDOWN_DIRECTORY = os.path.join(BASE_DIRECTORY, "ringdown_log")
HEALTHY_RINGDOWN_FILE = os.path.join(BASE_DIRECTORY, "healthy_ringdown.csv")

# Calculate and save Delta Amplitude
DELTA_AMPLITUDE_FILE = '/home/tuser/Desktop/ENGR498/ARULE4Python/ARULE/DATA/DINP/SP4000_2.csv'
DELTA_F_FILE = '/home/tuser/Desktop/ENGR498/ARULE4Python/ARULE/DATA/DINP/SP4000_3.csv'


os.makedirs(UPLOAD_DIRECTORY, exist_ok=True)
os.makedirs(RINGDOWN_DIRECTORY, exist_ok=True)
os.makedirs(DELTA_T_DIRECTORY, exist_ok=True)
# Ensure directories and counter file exist
os.makedirs(UPLOAD_DATA_DIRECTORY, exist_ok=True)
os.makedirs(COUNTER_FILE_DIRECTORY, exist_ok=True)




if not os.path.exists(COUNTER_FILE):
    with open(COUNTER_FILE, 'w') as f:
        f.write('0')  # Initialize the counter to 0


# Function to get the current counter value
def get_file_counter():
    with open(COUNTER_FILE, 'r') as f:
        return int(f.read().strip())


# Function to increment and save the counter
def increment_file_counter():
    counter = get_file_counter() + 1
    with open(COUNTER_FILE, 'w') as f:
        f.write(str(counter))
    return counter

def run_external_script():
    """
    Run the external Python script Team24502.py.
    """
    script_path = "/home/tuser/Desktop/ENGR498/ARULE4Python/DEMOS/Team24502.py"
    try:
        result = subprocess.run(
            ["python3", script_path],
            check=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True
        )

        print("External script output:\n", result.stdout)
        print("External script errors (if any):\n", result.stderr)

        # Paths for output files
        output_files = [
            "/home/tuser/Desktop/ENGR498/ARULE4Python/ARULE/DATA/DOUT/ND_1_DW_Team24502_SP4000_1_OUT.csv",
            "/home/tuser/Desktop/ENGR498/ARULE4Python/ARULE/DATA/DOUT/ND_2_DW_Team24502_SP4000_2_OUT.csv",
            "/home/tuser/Desktop/ENGR498/ARULE4Python/ARULE/DATA/DOUT/ND_3_DW_Team24502_SP4000_3_OUT.csv"
        ]

        # Destination paths
        destination_paths = [
            "/home/tuser/Desktop/ENGR498/data/ΔT/rulData.csv",
            "/home/tuser/Desktop/ENGR498/data/ΔA/rulData.csv",
            "/home/tuser/Desktop/ENGR498/data/ΔF/rulData.csv"
        ]

        # Copy each output file to the corresponding destination path
        for src, dest in zip(output_files, destination_paths):
            if os.path.exists(src):
                shutil.copy(src, dest)
                print(f"Copied {src} to {dest}")
            else:
                print(f"Warning: Source file {src} does not exist.")

        print("All files processed successfully!")

    except subprocess.CalledProcessError as e:
        print(f"Error while running external script: {e.stderr}")
    except Exception as e:
        print(f"Error during file copying or processing: {e}")


        
def calculate_and_save_delta_t(healthy_df, new_df, save_path, target_voltage=1.22):
    """
    Calculate the Delta T for a specific target voltage between healthy and new datasets
    and save results to a file.

    Args:
        healthy_df (pd.DataFrame): Healthy voltage decay data.
        new_df (pd.DataFrame): New voltage decay data.
        save_path (str): File path to save the Delta T data.
        target_voltage (float): Voltage value to search for.

    Returns:
        None
    """

    # Find the closest voltage in healthy data to the target voltage
    healthy_match = healthy_df.iloc[(healthy_df['Voltage'] - target_voltage).abs().idxmin()]
    healthy_voltage = healthy_match['Voltage']
    healthy_time = healthy_match['Time']

    # Debug healthy match
    print(f"Closest match in healthy data: voltage {healthy_voltage}, time {healthy_time}")

    # Find the closest voltage in new data to the target voltage
    new_match = new_df.iloc[(new_df['Voltage'] - target_voltage).abs().idxmin()]
    new_voltage = new_match['Voltage']
    new_time = new_match['Time']

    # Debug new match
    print(f"Closest match in new data: voltage {new_voltage}, time {new_time}")

    # Calculate Delta T
    delta_t = healthy_time - new_time
    print(f"Calculated Delta T: {delta_t}")

    # Determine the starting sample index
    if os.path.exists(save_path):
        existing_df = pd.read_csv(save_path, header=None, names=['Sample', 'Delta T'])
        if not existing_df.empty:
            next_index = existing_df['Sample'].max() + 1
        else:
            next_index = 0
    else:
        next_index = 0

    # Save Delta T to file
    delta_t_data = pd.DataFrame([(next_index, delta_t)], columns=['Sample', 'Delta T'])

    if os.path.exists(save_path):
        delta_t_data.to_csv(save_path, mode='a', index=False, header=False)
        print(f"Appended Delta T data to {save_path}")
    else:
        delta_t_data.to_csv(save_path, index=False)
        print(f"Saved Delta T data to {save_path}")




def process_voltage_decay(new_df):
    """Process voltage decay data."""
    print("Processing Voltage Decay Data...")
    
    # Save new voltage data
    file_counter = increment_file_counter()
    unique_filename = f"voltageDecay_{file_counter}.csv"
    voltage_save_path = os.path.join(UPLOAD_DATA_DIRECTORY, unique_filename)
    new_df.to_csv(voltage_save_path, index=False)
    print(f"Voltage decay data saved to: {voltage_save_path}")

    # Load healthy reference data
    if not os.path.exists(healthy_file_path):
        raise FileNotFoundError(f"Healthy reference file not found at {healthy_file_path}")

    healthy_df = pd.read_csv(healthy_file_path)
    healthy_df.columns = healthy_df.columns.str.strip()

    if 'Voltage' not in healthy_df.columns or 'Time' not in healthy_df.columns:
        raise ValueError("Healthy file missing 'Time' or 'Voltage' columns")

    # Calculate and save Delta T
    print("Calculating Delta T for Voltage Decay Data...")
    calculate_and_save_delta_t(healthy_df, new_df, DELTA_T_FILE)


    # Run the external script
    print("Running external script after voltage decay processing...")
    run_external_script()


def process_ringdown(new_df):
    """Process ringdown data."""
    print("Processing Ringdown Data...")

    # Save new ringdown data
    file_counter = increment_file_counter()
    unique_filename = f"ringdown_{file_counter}.csv"
    ringdown_save_path = os.path.join(RINGDOWN_DIRECTORY, unique_filename)
    new_df.to_csv(ringdown_save_path, index=False)
    print(f"Ringdown data saved to: {ringdown_save_path}")


    if not os.path.exists(HEALTHY_RINGDOWN_FILE):
        raise FileNotFoundError(f"Healthy ringdown file not found at {HEALTHY_RINGDOWN_FILE}")

    healthy_df = pd.read_csv(HEALTHY_RINGDOWN_FILE)
    healthy_df.columns = healthy_df.columns.str.strip()

    if 'Amplitude' not in healthy_df.columns or 'Time' not in healthy_df.columns:
        raise ValueError("Healthy file missing 'Time' or 'Amplitude' columns")

    # Calculate and save Delta Amplitude
    calculate_and_save_delta_amplitude(healthy_df, new_df, DELTA_AMPLITUDE_FILE)


    # Calculate and save Delta F (Frequency)
    #calculate_and_save_delta_f(healthy_df, new_df, DELTA_F_FILE)



    # Run the external script
    print("Running external script after ringdown processing...")
    run_external_script()


def calculate_and_save_delta_f(healthy_df, new_df, save_path):
    """
    Calculate the Delta F (frequency difference) between healthy and new datasets
    based on the first three amplitude peaks, and save results to a file.

    Args:
        healthy_df (pd.DataFrame): Healthy amplitude data with 'Time' and 'Amplitude'.
        new_df (pd.DataFrame): New amplitude data with 'Time' and 'Amplitude'.
        save_path (str): File path to save the Delta F data.

    Returns:
        None
    """

    def find_first_three_peaks(df):
        """Find the times of the first three amplitude peaks in the data."""
        peaks, _ = find_peaks(df['Amplitude'])
        if len(peaks) < 3:
            raise ValueError("The dataset has fewer than 3 peaks.")
        return df.loc[peaks[:3], 'Time'].values

    # Find the first three peaks for healthy data
    healthy_peak_times = find_first_three_peaks(healthy_df)
    healthy_period = ((healthy_peak_times[1] - healthy_peak_times[0]) +
                      (healthy_peak_times[2] - healthy_peak_times[1])) / 2
    healthy_frequency = 1 / healthy_period

    # Debug healthy frequency
    print(f"Healthy data: Peaks at times {healthy_peak_times}, Period = {healthy_period}, Frequency = {healthy_frequency}")

    # Find the first three peaks for new data
    new_peak_times = find_first_three_peaks(new_df)
    new_period = ((new_peak_times[1] - new_peak_times[0]) +
                  (new_peak_times[2] - new_peak_times[1])) / 2
    new_frequency = 1 / new_period

    # Debug new frequency
    print(f"New data: Peaks at times {new_peak_times}, Period = {new_period}, Frequency = {new_frequency}")

    # Calculate Delta F
    delta_f = healthy_frequency - new_frequency #235
    print(f"Calculated Delta F: {delta_f}")

    # Determine the starting sample index
    if os.path.exists(save_path):
        existing_df = pd.read_csv(save_path, header=None, names=['Sample', 'Delta F'])
        if not existing_df.empty:
            next_index = existing_df['Sample'].max() + 1
        else:
            next_index = 0
    else:
        next_index = 0

    # Save Delta F to file
    delta_f_data = pd.DataFrame([(next_index, delta_f)], columns=['Sample', 'Delta F'])

    if os.path.exists(save_path):
        delta_f_data.to_csv(save_path, mode='a', index=False, header=False)
        print(f"Appended Delta F data to {save_path}")
    else:
        delta_f_data.to_csv(save_path, index=False)
        print(f"Saved Delta F data to {save_path}")



def calculate_and_save_delta_amplitude(healthy_df, new_df, save_path):
    """
    Calculate the Delta Amplitude (Max Amplitude Difference) between healthy and new datasets
    and save results to a file.

    Args:
        healthy_df (pd.DataFrame): Healthy ringdown data with 'Time' and 'Amplitude' columns.
        new_df (pd.DataFrame): New ringdown data with 'Time' and 'Amplitude' columns.
        save_path (str): File path to save the Delta Amplitude data.

    Returns:
        None
    """

    # Find max amplitude and corresponding time in healthy data
    healthy_max_amplitude = healthy_df['Amplitude'].max()
    healthy_time_of_max = healthy_df.loc[healthy_df['Amplitude'].idxmax(), 'Time']

    # Debug healthy match
    print(f"Healthy max amplitude: {healthy_max_amplitude} at time {healthy_time_of_max}")

    # Find max amplitude and corresponding time in new data
    new_max_amplitude = new_df['Amplitude'].max()
    new_time_of_max = new_df.loc[new_df['Amplitude'].idxmax(), 'Time']

    # Debug new match
    print(f"New max amplitude: {new_max_amplitude} at time {new_time_of_max}")

    # Calculate Delta Amplitude
    delta_amplitude = healthy_max_amplitude - new_max_amplitude
    print(f"Calculated Delta Amplitude: {delta_amplitude}")

    # Determine the starting sample index
    if os.path.exists(save_path):
        existing_df = pd.read_csv(save_path, header=None, names=['Sample', 'Delta Amplitude'])
        if not existing_df.empty:
            next_index = existing_df['Sample'].max() + 1
        else:
            next_index = 0
    else:
        next_index = 0

    # Save Delta Amplitude to file
    delta_amplitude_data = pd.DataFrame([(next_index, delta_amplitude)], columns=['Sample', 'Delta Amplitude'])

    if os.path.exists(save_path):
        delta_amplitude_data.to_csv(save_path, mode='a', index=False, header=False)
        print(f"Appended Delta Amplitude data to {save_path}")
    else:
        delta_amplitude_data.to_csv(save_path, index=False)
        print(f"Saved Delta Amplitude data to {save_path}")


 
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload_file():


    global script_run_flag


    try:
        # Read raw CSV data
        csv_data = request.data.decode('utf-8')
        if not csv_data:
            return jsonify({"error": "No data received"}), 400

        # Convert CSV to DataFrame
        csv_stream = StringIO(csv_data)
        new_df = pd.read_csv(csv_stream)
        new_df.columns = new_df.columns.str.strip()

        # Check the type of incoming data
        if 'Voltage' in new_df.columns and 'Time' in new_df.columns:
            # Handle Voltage Decay Data
            process_voltage_decay(new_df)
        elif 'Amplitude' in new_df.columns and 'Time' in new_df.columns:
            # Handle Ringdown Data
            process_ringdown(new_df)
        else:
            return jsonify({"error": "Unknown file format. Missing expected columns."}), 400


        # Run the external script if it hasn't been executed for this batch
        if not script_run_flag:
            print("Running external script...")
            run_external_script()
            script_run_flag = True  # Mark as executed for this batch



        # Traverse `data` directory to find all `voltageData.csv` files
        overridden_files = []
        for root, dirs, files in os.walk(DATA_DIRECTORY):  # Recursively walk through directories
            for file in files:
                if file == 'voltageData.csv':  # Check for `voltageData.csv`
                    file_path = os.path.join(root, file)
                    
                    # Check if the new data contains 'Time' and 'Voltage' columns
                    if 'Time' in new_df.columns and 'Voltage' in new_df.columns:
                        # Override the file content with normalized data
                        new_df.to_csv(file_path, index=False)  # Save normalized DataFrame
                        overridden_files.append(file_path)
                    else:
                        print(f"Skipping override for {file_path} as it does not contain 'Time' and 'Voltage' columns.")

        # Output response
        print(f"Overridden files: {overridden_files}")  # Debug log


        # Check file content after saving Delta T
        if os.path.exists(DELTA_T_FILE):
            print("Delta T file content:")
            with open(DELTA_T_FILE, 'r') as f:
                print(f.read())


        if os.path.exists(DELTA_AMPLITUDE_FILE):
            print("Delta A file content:")
            with open(DELTA_AMPLITUDE_FILE, 'r') as f:
                print(f.read())



        if os.path.exists(DELTA_F_FILE):
            print("Delta F file content:")
            with open(DELTA_F_FILE, 'r') as f:
                print(f.read())

        # Return response
        return jsonify({"message": "Processed new voltage data and saved Delta T."}), 200

    except Exception as e:
        print(f"Error processing CSV: {e}")
        return jsonify({"error": str(e)}), 500




# Endpoint to list all devices (subdirectories in the DATA_DIRECTORY)
@app.route('/list_devices', methods=['GET'])
def list_devices():
    try:
        # List all directories (devices) within the DATA_DIRECTORY
        devices = [d for d in os.listdir(DATA_DIRECTORY) if os.path.isdir(os.path.join(DATA_DIRECTORY, d))]
        return jsonify(devices)
    except Exception as e:
        return jsonify({"error": str(e)}), 500
    

    

# Endpoint to get voltage data for a specific device
@app.route('/data/<device>/voltageData.csv', methods=['GET'])
def get_voltage_data(device):
    file_path = os.path.join(DATA_DIRECTORY, device, 'voltageData.csv')
    
    if not os.path.exists(file_path):
        return abort(404, description="Voltage data file not found.")
    
    # Load the CSV data into a pandas DataFrame
    df = pd.read_csv(file_path)
    
    # Check if the necessary columns exist in the CSV
    if 'Time' not in df.columns or 'Voltage' not in df.columns:
        return abort(400, description="CSV file must contain 'Time' and 'Voltage' columns.")
    
    # Convert the DataFrame to a dictionary suitable for JSON
    data = {
        "time": df['Time'].tolist(),
        "voltage": df['Voltage'].tolist()
    }
    
    return jsonify(data)

@app.route('/data/<device>/rulData.csv', methods=['GET'])
def get_rul_fd_soh_data(device):
    file_path = os.path.join(DATA_DIRECTORY, device, 'rulData.csv')
    
    if not os.path.exists(file_path):
        return abort(404, description="RUL data file not found.")
    
    try:
        df = pd.read_csv(file_path)
        
        # Ensure all required columns exist
        required_columns = ['DT', 'RUL', 'PH', 'FD', 'SOH']
        missing_columns = [col for col in required_columns if col not in df.columns]
        if missing_columns:
            return abort(400, description=f"Missing columns: {', '.join(missing_columns)}")
        
        # Prepare JSON response
        data = {
            "time": df['DT'].tolist(),
            "rul": df['RUL'].tolist(),
            "ph": df['PH'].tolist(),
            "fd": df['FD'].tolist(),
            "eol": df['EOL'].tolist() if 'EOL' in df.columns else [0] * len(df),
            "bd": df['BD'].tolist() if 'BD' in df.columns else [0] * len(df),
            "soh": df['SOH'].tolist()
        }
        return jsonify(data)
    except Exception as e:
        print("Error:", e)  # Debug error
        return jsonify({"error": str(e)}), 500
    

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
