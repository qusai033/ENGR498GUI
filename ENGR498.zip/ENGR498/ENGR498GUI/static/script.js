let voltageChart = null;  // Declare chart globally so it can be destroyed later
// This variable will hold the Chart.js instance for the voltage chart. 
// It is initialized as `null` and can be replaced with a new chart instance when needed.

let rulChart = null;  // Declare a global variable for the RUL (health) chart
// This variable will hold the Chart.js instance for the Remaining Useful Life (RUL) chart.

let allDevices = [];  // Store the list of all devices for filtering
// This array will store the list of devices retrieved from the server or user input, 
// enabling filtering and displaying devices dynamically.

let sohChart = null;  // Declare a global variable for the State-of-Health chart
// This variable will hold the Chart.js instance for the State-of-Health (SoH) chart.

let fdChart = null;  // Declare a global variable for the Feature Data chart
// This variable will hold the Chart.js instance for the Feature Data (FD) chart.

let verticalLines = [
    { x: null, label: 'End of Life', visible: true, color: 'red'}, 
    // Represents a vertical line marking the 'End of Life' on the graph. 
    // The `x` value is the time where the line is drawn. Initially set to `null`.
    { x: null, label: 'Beginning of Degradation', visible: true, color: 'green'}
    // Represents a vertical line marking the 'Beginning of Degradation' on the graph.
    // The `x` value is the time where the line is drawn. Initially set to `null`.
];
// `verticalLines` is an array of objects, each representing a vertical line on the charts. 
// Each object includes:
// - `x`: The x-coordinate where the line is drawn (time on the x-axis).
// - `label`: A descriptive label for the line.
// - `visible`: A boolean to toggle the visibility of the line.
// - `color`: The color of the line.

let lastData = '';  // Variable to store the most recent data string or response
// This variable will hold the last data received or processed. 
// It can be used to track changes, prevent redundant processing, or debug issues.



function zoomStatus(chart) {
    return chart.scales.x.min + ' - ' + chart.scales.x.max;
}

function panStatus(chart) {
    return chart.options.plugins.zoom.pan.enabled ? 'Enabled' : 'Disabled';
}

// Define zoom and pan options for the chart
const zoomOptions = {
    limits: { // Set limits for x and y axes
      x: { min: -200, max: 200, minRange: 50 },
      y: { min: -200, max: 200, minRange: 50 }
    },
    pan: { // Enable panning on both axes
      enabled: true,
      mode: 'xy'
    },
    zoom: { // Enable zooming with wheel and pinch gestures
      wheel: { enabled: true },
      pinch: { enabled: true },
      mode: 'xy',
      onZoomComplete({ chart }) {
        chart.update('none'); // Update chart without redrawing other elements
      }
    }
};

// Function to reset zoom for all charts
function resetZoom() {
    if (voltageChart) voltageChart.resetZoom(); // Reset zoom on voltage chart
    if (rulChart) rulChart.resetZoom();       // Reset zoom on RUL chart
    if (sohChart) sohChart.resetZoom();       // Reset zoom on SoH chart
    if (fdChart) fdChart.resetZoom();         // Reset zoom on FD chart
}


// Function to load all devices from the server
function loadDevices() {
    fetch('/list_devices')
        .then(response => response.json())
        .then(devices => {
            allDevices = devices; // Store the list of all devices for filtering
            displayDevices(devices); // Display the full list of devices initially
        })
        .catch(error => console.error('Error loading devices:', error));
}

// Function to get the unit for a given device
function getUnitForDevice(device) {
    const unitMapping = { // Map devices to their respective units
        "ΔF": "ΔF",
        "ΔT": "ΔT",
        "ΔA": "ΔA",
    };
    return unitMapping[device] || "AU"; // Return unit or default to "AU"
}

function showGraphsForDevice(device) {
    console.log("Switching to Tests:", device);

    // Fetch Voltage Data
    fetch(`/data/${device}/voltageData.csv`)
        .then(response => response.json())
        .then(data => {
            // Ensure data arrays are non-empty
            if (!data.time || data.time.length === 0) {
                data.time = [0]; // Default to a single zero entry
                data.voltage = [0]; // Default voltage value
            }
            updateVoltageChart(data); // Update voltage chart with fetched data
        })
        .catch(error => console.error('Error loading voltage data:', error)); // Log errors


    // Fetch RUL Data
    fetch(`/data/${device}/rulData.csv`) // Request RUL data for the selected device
        .then(response => response.json())
        .then(data => {
            console.log("Fetched Data for Device:", device); // Log fetched device name
            console.log("Fetched Data:", data); // Log fetched data

            // Clear previous vertical line states
            verticalLines[0].x = null; // Reset End of Life (EOL) line
            verticalLines[1].x = null; // Reset Beginning of Degradation (BD) line

            // Ensure arrays are valid and replace invalid values with 0
            Object.keys(data).forEach(key => {
                if (Array.isArray(data[key])) {
                    data[key] = data[key].map(value => isNaN(value) ? 0 : value); // Replace NaN with 0
                }
            });

            // Determine indices for BD and EOL, defaulting to zero if not found
            const bdIndex = data.bd.findIndex(value => value !== 0) || 0;
            const eolIndex = data.eol.findIndex(value => value !== 0) || 0;

            // Update vertical lines with BD and EOL time values
            verticalLines[1].x = data.time[bdIndex]; // Set BD line position
            verticalLines[0].x = data.time[eolIndex]; // Set EOL line position

            console.log("Updated Vertical Lines:", verticalLines); // Log updated lines

            const unit = getUnitForDevice(device); // Get appropriate unit for the device
            updateFDChart(data, bdIndex, eolIndex, unit); // Update FD chart with new data and unit

            // Update remaining charts with fetched data and indices
            updateRulChart(data, bdIndex, eolIndex);
            updateSoHChart(data, bdIndex, eolIndex);
        })
        .catch(error => console.error('Error loading RUL data:', error)); // Log errors
}


const annotationPlugin = {
    id: 'dynamicAnnotationPlugin', // Unique ID for the plugin
    beforeDraw: (chart) => {
        const ctx = chart.ctx; // Get the canvas rendering context
        const xScale = chart.scales.x; // Access the x-axis scale
        const yScale = chart.scales.y; // Access the y-axis scale

        const bdIndex = chart.data.bdIndex; // Index of the Beginning of Degradation (BD)
        const eolIndex = chart.data.eolIndex; // Index of the End of Life (EOL)

        // Draw a circle for the BD point if valid
        if (bdIndex !== null && bdIndex >= 0) {
            const xPixel = xScale.getPixelForValue(chart.data.labels[bdIndex]); // Get x-coordinate for BD
            const yPixel = yScale.getPixelForValue(chart.data.datasets[0].data[bdIndex]); // Get y-coordinate for BD
            ctx.save(); // Save the current state
            ctx.beginPath();
            ctx.arc(xPixel, yPixel, 8, 0, 2 * Math.PI); // Draw a circle at BD
            ctx.lineWidth = 2; // Set line thickness
            ctx.strokeStyle = 'green'; // Set stroke color for BD
            ctx.stroke(); // Render the circle
            ctx.restore(); // Restore the previous state
        }

        // Draw a circle for the EOL point if valid
        if (eolIndex !== null && eolIndex >= 0) {
            const xPixel = xScale.getPixelForValue(chart.data.labels[eolIndex]); // Get x-coordinate for EOL
            const yPixel = yScale.getPixelForValue(chart.data.datasets[0].data[eolIndex]); // Get y-coordinate for EOL
            ctx.save(); // Save the current state
            ctx.beginPath();
            ctx.arc(xPixel, yPixel, 8, 0, 2 * Math.PI); // Draw a circle at EOL
            ctx.lineWidth = 2; // Set line thickness
            ctx.strokeStyle = 'red'; // Set stroke color for EOL
            ctx.stroke(); // Render the circle
            ctx.restore(); // Restore the previous state
        }
    }
};



const verticalLinePlugin = {
    id: 'verticalLinePlugin', // Unique ID for the plugin
    beforeDraw: (chart) => {
        const ctx = chart.ctx; // Get the canvas rendering context
        const xScale = chart.scales.x; // Access the x-axis scale
        const yScale = chart.scales.y; // Access the y-axis scale

        // Check if scales are properly initialized
        if (!xScale || !yScale) {
            console.warn("Scales not initialized. Cannot draw vertical lines.");
            return; // Exit if scales are not available
        }

        // Iterate through the vertical lines array
        verticalLines.forEach(line => {
            // Skip lines that are not visible or have a null x-coordinate
            if (!line.visible || line.x === null) {
                console.log("Skipping line:", line);
                return;
            }

            const xPixel = xScale.getPixelForValue(line.x); // Get the x-coordinate in pixels

            // Skip lines with invalid pixel calculations
            if (isNaN(xPixel) || xPixel === undefined) {
                console.warn("Invalid xPixel for line:", line, "xScale domain:", xScale.min, "-", xScale.max);
                return;
            }

            // Draw the vertical dashed line
            ctx.save(); // Save the current state
            ctx.setLineDash([5, 5]); // Use a dashed line style
            ctx.beginPath();
            ctx.moveTo(xPixel, yScale.top); // Start from the top of the chart
            ctx.lineTo(xPixel, yScale.bottom); // Extend to the bottom of the chart
            ctx.lineWidth = 2; // Set line thickness
            ctx.strokeStyle = line.color; // Use the specified line color
            ctx.stroke(); // Render the line
            ctx.restore(); // Restore the previous state

            // Add a label above the line
            ctx.setLineDash([]); // Reset the line dash style for the label
            ctx.font = '12px Arial'; // Set font for the label
            ctx.fillStyle = line.color; // Use the same color as the line
            ctx.textAlign = 'center'; // Center-align the label text
            ctx.fillText(line.label, xPixel, yScale.top - 10); // Position the label above the line
        });
    }
};


// Update the RUL chart with JSON data (no need to parse with parseData)
function updateRulChart(data, bdIndex, eolIndex) {
    const ctx = document.getElementById('rulChart').getContext('2d'); // Get canvas context for the chart

    if (rulChart) rulChart.destroy(); // Destroy the existing chart instance if it exists

    // Create a new RUL chart
    rulChart = new Chart(ctx, {
        type: 'line', // Chart type: line chart
        data: {
            labels: data.time, // X-axis labels (time values)
            datasets: [
                {
                    label: 'Remaining Useful Life (RUL)', // First dataset: RUL
                    data: data.rul, // Data for RUL
                    borderColor: 'rgb(255, 165, 0)', // Line color: orange
                    tension: 0.1, // Line tension for smoothing
                    fill: false, // Disable fill under the line
                    pointRadius: 0 // Hide points on the line
                },
                {
                    label: 'Prognostic Horizon (PH)', // Second dataset: PH
                    data: data.ph, // Data for PH
                    borderColor: 'rgb(0, 150, 136)', // Line color: green
                    tension: 0.1, // Line tension for smoothing
                    fill: false, // Disable fill under the line
                    pointRadius: 0 // Hide points on the line
                }
            ],
            bdIndex: bdIndex, // Beginning of Degradation index
            eolIndex: eolIndex // End of Life index
        },
        options: {
            responsive: true, // Make chart responsive
            maintainAspectRatio: true, // Preserve aspect ratio
            scales: {
                x: { title: { display: true, text: 'Time [Hour]' } }, // X-axis title
                y: { title: { display: true, text: 'RUL/PH [Hour]' } } // Y-axis title
            },
            plugins: {
                zoom: zoomOptions // Enable zoom and pan options
            }
        },
 
        plugins: [
            // Plugin to draw annotations for the first dataset (RUL)
            {
            id: 'dynamicAnnotationPlugin',
            beforeDraw: (chart) => {
                const ctx = chart.ctx;
                const xScale = chart.scales.x;
                const yScale = chart.scales.y;
        
                const bdIndex = chart.data.bdIndex;
                const eolIndex = chart.data.eolIndex;



                // Draw annotation for Beginning of Degradation (BD)
                if (bdIndex !== null && bdIndex >= 0) {
                    const xPixel = xScale.getPixelForValue(chart.data.labels[bdIndex]);
                    const yPixel = yScale.getPixelForValue(chart.data.datasets[0].data[bdIndex]);
                    ctx.save();
                    ctx.beginPath();
                    ctx.arc(xPixel, yPixel, 8, 0, 2 * Math.PI); // Circle for BD
                    ctx.lineWidth = 2;
                    ctx.strokeStyle = 'green';
                    ctx.stroke();
                    ctx.restore();
                }
                
                // Draw annotation for End of Life (EOL)
                if (eolIndex !== null && eolIndex >= 0) {
                    const xPixel = xScale.getPixelForValue(chart.data.labels[eolIndex]);
                    const yPixel = yScale.getPixelForValue(chart.data.datasets[0].data[eolIndex]);
                    ctx.save();
                    ctx.beginPath();
                    ctx.arc(xPixel, yPixel, 8, 0, 2 * Math.PI); // Circle for EOL
                    ctx.lineWidth = 2;
                    ctx.strokeStyle = 'red';
                    ctx.stroke();
                    ctx.restore();
                }
            }
        },

        // Plugin to draw annotations for the second dataset (PH)
        {
            id: 'dynamicAnnotationPlugin',
            beforeDraw: (chart) => {
                const ctx = chart.ctx;
                const xScale = chart.scales.x;
                const yScale = chart.scales.y;
        
                const bdIndex = chart.data.bdIndex;
                const eolIndex = chart.data.eolIndex;


                // Draw annotation for Beginning of Degradation (BD) in PH dataset
                if (bdIndex !== null && bdIndex >= 0) {
                    const xPixel = xScale.getPixelForValue(chart.data.labels[bdIndex]);
                    const yPixel = yScale.getPixelForValue(chart.data.datasets[1].data[bdIndex]);
                    ctx.save();
                    ctx.beginPath();
                    ctx.arc(xPixel, yPixel, 8, 0, 2 * Math.PI); // Circle for BD
                    ctx.lineWidth = 2;
                    ctx.strokeStyle = 'green';
                    ctx.stroke();
                    ctx.restore();
                }

                // Draw annotation for End of Life (EOL) in PH dataset 
        
                if (eolIndex !== null && eolIndex >= 0) {
                    const xPixel = xScale.getPixelForValue(chart.data.labels[eolIndex]);
                    const yPixel = yScale.getPixelForValue(chart.data.datasets[1].data[eolIndex]);
                    ctx.save();
                    ctx.beginPath();
                    ctx.arc(xPixel, yPixel, 8, 0, 2 * Math.PI); // Circle for EOL
                    ctx.lineWidth = 2;
                    ctx.strokeStyle = 'red';
                    ctx.stroke();
                    ctx.restore();
                }
            }
        }]
    });
}

function updateSoHChart(data, bdIndex, eolIndex) {
    const ctx = document.getElementById('sohChart').getContext('2d'); // Get canvas context for the SoH chart

    if (sohChart) sohChart.destroy(); // Destroy the existing chart if it exists

    // Create a new State-of-Health (SoH) chart
    sohChart = new Chart(ctx, {
        type: 'line', // Line chart type
        data: {
            labels: data.time, // Time values for the x-axis
            datasets: [{
                label: 'State-of-Health (SoH)', // Label for the dataset
                data: data.soh, // SoH data points
                borderColor: 'rgb(189, 26, 26)', // Line color: red
                tension: 0.1, // Smooth line tension
                fill: false, // Disable fill under the line
                pointRadius: 0 // Hide data points
            }],
            bdIndex: bdIndex, // Beginning of Degradation index
            eolIndex: eolIndex // End of Life index
        },
        options: {
            responsive: true, // Make the chart responsive
            maintainAspectRatio: true, // Maintain aspect ratio
            scales: {
                x: { title: { display: true, text: 'Time [Hour]' } }, // X-axis title
                y: { title: { display: true, text: 'SoH [%]' } } // Y-axis title
            },
            plugins: {
                zoom: zoomOptions // Apply zoom and pan options
            }
        },
        plugins: [annotationPlugin] // Add annotation plugin for BD and EOL markers
    });
}



function updateFDChart(data, bdIndex, eolIndex, unit = 'AU') {
    const ctx = document.getElementById('fdChart').getContext('2d'); // Get the canvas context for FD chart

    if (fdChart) fdChart.destroy(); // Destroy the existing chart if it exists

    // Update vertical lines with BD and EOL indices
    verticalLines[0].x = eolIndex >= 0 ? data.time[eolIndex] : null; // EOL line
    verticalLines[1].x = bdIndex >= 0 ? data.time[bdIndex] : null; // BD line

    // Clean BD and EOL data to ensure numeric values
    const cleanBd = data.bd.map(value => Number(value)).filter(value => !isNaN(value));
    const cleanEol = data.eol.map(value => Number(value)).filter(value => !isNaN(value));

    // Dynamically determine BD and EOL indices
    const fdBdIndex = cleanBd.findIndex(value => value !== 0);
    const fdEolIndex = cleanEol.findIndex(value => value !== 0);

    // Update vertical line positions based on indices
    if (fdBdIndex >= 0) verticalLines[1].x = data.time[fdBdIndex];
    if (fdEolIndex >= 0) verticalLines[0].x = data.time[fdEolIndex];

    console.log("Updated Vertical Lines for FD:", verticalLines); // Debug log for vertical lines

    // Create the Feature Data (FD) chart
    fdChart = new Chart(ctx, {
        type: 'line', // Line chart type
        data: {
            labels: data.time, // Time data for x-axis
            datasets: [{
                label: 'Feature Data (FD)', // Dataset label
                data: data.fd, // FD data points
                borderColor: 'rgb(0, 4, 53)', // Line color: dark blue
                tension: 0.1, // Smooth line
                fill: false, // Disable area fill
                pointRadius: 0, // No points on the line
                pointBackgroundColor: (context) => {
                    // Highlight BD and EOL points
                    if (context.dataIndex === fdEolIndex) return 'red'; // EOL point
                    if (context.dataIndex === fdBdIndex) return 'green'; // BD point
                    return 'transparent'; // Default: no color
                },
                pointBorderWidth: (context) => {
                    // Customize border width for BD and EOL points
                    if (context.dataIndex === fdEolIndex || context.dataIndex === fdBdIndex) return 1;
                    return 1; // Default width
                }
            }]
        },
        options: {
            responsive: true, // Make chart responsive
            maintainAspectRatio: true, // Preserve aspect ratio
            scales: {
                x: { title: { display: true, text: 'Time [Hour]' } }, // X-axis title
                y: { title: { display: true, text: `FD [${unit}]` } } // Y-axis title with dynamic unit
            },
            plugins: {
                zoom: zoomOptions // Enable zoom and pan functionality
            }
        },
        plugins: [verticalLinePlugin] // Add vertical line plugin
    });

    adjustCharts(); // Adjust chart size dynamically after creation
}



// Update the voltage chart with the fetched data
function updateVoltageChart(data) {
    const ctx = document.getElementById('voltageChart').getContext('2d'); // Get the canvas context for the voltage chart

    if (voltageChart) voltageChart.destroy(); // Destroy the existing chart to prevent duplication

    // Create a new voltage chart
    voltageChart = new Chart(ctx, {
        type: 'line', // Line chart type
        data: {
            labels: data.time, // Time values for the x-axis
            datasets: [{
                label: 'Voltage Decay', // Dataset label
                data: data.voltage, // Voltage data points
                borderColor: 'rgb(158, 197, 254)', // Line color: light blue
                tension: 0.1, // Smooth line
                fill: false, // Disable area fill under the line
                pointRadius: 0, // No visible points on the line
                pointBackgroundColor: 'transparent', // Transparent point background
                pointBorderWidth: 1 // Border width for points (if enabled)
            }]
        },
        options: {
            responsive: true, // Make chart responsive
            maintainAspectRatio: true, // Maintain chart aspect ratio
            scales: {
                x: { title: { display: true, text: 'Time [MS]' } }, // X-axis title
                y: { title: { display: true, text: 'Voltage [V]' } } // Y-axis title
            },
            plugins: {
                zoom: zoomOptions // Enable zoom and pan functionality
            }
        },
        plugins: [annotationPlugin] // Add annotation plugin for marking specific points
    });

    adjustCharts(); // Dynamically adjust chart size for its container
}


function parseCsvData(data) {
    const lines = data.split('\n'); // Split the CSV data into lines
    const headers = lines[0].split(','); // Extract headers from the first line
    const result = {};

    // Initialize result arrays for each column
    headers.forEach(header => result[header] = []);

    // Populate result arrays
    lines.slice(1).forEach(line => { // Loop through each data row (skipping the header)
        const values = line.split(','); // Split the row into individual values
        headers.forEach((header, index) => { // Map each value to the corresponding header
            if (values[index]) { // Check if the value exists
                result[header].push(parseFloat(values[index])); // Parse and store as a float
            }
        });
    });

    return result;  // Return an object with arrays for each column
}

// Function to display the filtered devices in the dropdown
function displayDevices(devices) {
    const deviceList = document.getElementById('searchResults');
    deviceList.innerHTML = '';  // Clear the existing list

    devices.forEach(device => {
        const div = document.createElement('div'); // Create a div for each device
        div.textContent = device; // Set the device name as the text content
        div.classList.add('device-item'); // Add a CSS class for styling
        div.onclick = function() {
            showGraphsForDevice(device); // Load graphs when clicking on a device
        };
        deviceList.appendChild(div); // Append the device item to the list
    });

    // Show dropdown if devices exist, otherwise hide it
    document.querySelector('.search-results').style.display = devices.length ? 'block' : 'none'; 
}


// Function to toggle visibility of a specific vertical line
function toggleVerticalLine(index) {
    if (verticalLines[index]) { // Check if the vertical line exists
        verticalLines[index].visible = !verticalLines[index].visible; // Toggle visibility
        fdChart.update(); // Refresh the chart to reflect changes
    }
}

// Function to filter devices based on search input
function filterDevices() {
    const query = document.getElementById('deviceSearch').value.toLowerCase(); // Get the search query in lowercase
    const filteredDevices = allDevices.filter(device => device.toLowerCase().includes(query)); // Filter devices
    displayDevices(filteredDevices); // Update the displayed devices
}

// Function to send a GET request to a specified action on the Arduino
function sendRequest(action) {
    fetch(`http://192.168.0.69${action}`, { method: 'GET' }) // Send a GET request
        .then(response => response.text()) // Parse the response as text
        .then(data => console.log('Response from Arduino:', data)) // Log the Arduino's response
        .catch(error => console.error('Error:', error)); // Handle any errors
}

// Function to adjust and resize all active charts
function adjustCharts() {
    const charts = [voltageChart, rulChart, sohChart, fdChart]; // List of all chart objects
    charts.forEach(chart => {
        if (chart) {
            chart.resize(); // Resize the chart if it exists
        }
    });
}


// Attach resize event listener
window.addEventListener('resize', () => {
    adjustCharts();
});

// Load devices on page load
window.onload = loadDevices;