#Import Libraries
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import os

# Function to load data from a CSV file
def load_csv(file_path):
    data = pd.read_csv(file_path)
    return data.iloc[:, 0].values, data.iloc[:, 1].values

# Function to find the maximum amplitude in a dataset
def find_max_amplitude(file_path):
    _, Voltage = load_csv(file_path)
    return np.max(Voltage)

# Function to process new datasets and compare them to the baseline
def process_ring_data(baseline_file, new_files):
    # Compute baseline maximum amplitude
    max_amp1 = find_max_amplitude(baseline_file)
    print(f"Baseline maximum amplitude (Dataset 1): {max_amp1}")

    differences = []  # List to store differences
    file_labels = []  # List to store file labels for the x-axis

    # Loop through new files and compare their maximum amplitudes to the baseline
    for file in new_files:
        max_amp2 = find_max_amplitude(file)
        difference = abs(max_amp2 - max_amp1)
        differences.append(difference)
        file_labels.append(os.path.basename(file))  # Use the filename as the label

        print(f"File: {file}")
        print(f"Maximum amplitude: {max_amp2}")
        print(f"Difference from baseline: {difference}\n")

        # Optional: Plot for each comparison
        time, amp = load_csv(file)
        plt.figure(figsize=(10, 6))
        plt.plot(time, amp, label=f"Dataset ({file})", color="green")
        plt.axhline(max_amp1, color="red", linestyle="--", label=f"Baseline Max: {max_amp1:.2f}")
        plt.axhline(max_amp2, color="blue", linestyle="--", label=f"Current Max: {max_amp2:.2f}")
        plt.title(f"Comparison of Dataset ({file}) with Baseline")
        plt.xlabel("Time (uS)")
        plt.ylabel("Amplitude (mV)")
        plt.legend()
        plt.grid(True)
        plt.show()

    # Plot the differences over the datasets
    plt.figure(figsize=(10, 6))
    plt.plot(file_labels, differences, marker="o", linestyle="-", color="purple", label="Difference from Baseline")
    plt.title("Differences in Maximum Amplitudes")
    plt.xlabel("Dataset")
    plt.ylabel("Difference in Maximum Amplitude")
    plt.xticks(rotation=45)  # Rotate x-axis labels for better visibility
    plt.grid(True)
    plt.legend()
    plt.tight_layout()
    plt.show()

    #export the differences of the files to a .csv file
    differences_df = pd.DataFrame({
        "Dataset":file_labels,
        "Abs Difference":differences
    })
    
    differences_df.to_csv('Amplitude_differences.csv')
    
#Examples
#Define the baseline file, typically first reading
baseline_file = "Ringdown-Voltage 44uF.csv"

#Add new files as we go, need to add code that appends files to this list
new_files = [
    "Ringdown-Voltage 32uF.csv",  # Replace with actual file paths
    "Ringdown-Voltage 22uF.csv",
    "Ringdown-Voltage 10uF.csv",
]

process_ring_data(baseline_file, new_files)
