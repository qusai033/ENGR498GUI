TO RUN COMMANDLINE ARULE Linux:
	1. Make sure you have a folder with structure:
		ARULE
		----->DATA
		      ----->CPT
		      ----->DINP
		      ----->DOUT
		      ----->LOG
		      ----->SAVE
		----->DEFS
                      ----->NDEF
                      ----->SDEF
                  
	1. ./arule_linux.out <<NAME OF SDEF FILE>>  1 0 1 <<DIRECTORY WHERE ARULE FOLDER IS LOCATED>>
		for example: ./arule_linux.out DEMO2 1 0 1 /home/user 
			This will run DEMO2 in the ARULE directory in /home/user directory. 
			Output can be found in the /home/user/ARULE/DOUT directory
							
